import json 
import csv

with open('data.json') as fichierJSON:
    données = json.load(fichierJSON)
    with open('Numéros.csv', 'w') as fichierCSV:
        CSVwriter = csv.writer(fichierCSV, delimiter = ',')
        CSVwriter.writerow([données[0][0], données[0][1]])
        CSVwriter.writerow([données[1][0], données[1][1]])
        CSVwriter.writerow([données[2][0], données[2][1]])