import csv

def lireFichierCSV():

    dictioPokemons = {}
    with open("Pokemon.csv") as fichier:
        fichierL = csv.reader(fichier, delimiter = ',')
        

        for ligne in fichierL:
            nomPokemon = ligne[0]
            stats = list(map(int, ligne[1:]))
            dictioPokemons[nomPokemon] = stats
        
        return dictioPokemons

print(lireFichierCSV())
